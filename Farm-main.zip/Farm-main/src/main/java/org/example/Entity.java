package org.example;

public class Entity {
    public int id;
    protected String name;
    public String getDescription(){

    return "";
    }



}
